import java.lang.System;
import java.lang.StringBuilder;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.nio.ByteBuffer;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class bpf_patcher {

    // ADD        R?,-0x1
    static int[] add_i0x1_d = {0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1};

    // STXH       [R? + 0x?],R?
    static int[] stxh_so_d = {0, 1, 1, 0, 1, 0, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    // AND        R?,0xffff
    static int[] and_i0xffff_d = {0, 1, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    // MOV        R?,R?
    static int[] mov_s_d = {1, 0, 1, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    // STXB       [R? + 0x?],R?
    static int[] stxb_so_d = {0, 1, 1, 1, 0, 0, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    // AND        R?,0xff
    static int[] and_s_i0xff = {0, 1, 0, 1, 0, 1, 1, 1, 0, 0, 0, 0, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    // SUB        R?,R?
    static int[] sub_s_d = {0, 0, 0, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    // LSH        R?,0x8
    static int[] lsh_i0x8_d = {0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    // ADD        R?,0xffff
    static int[] add_i0xffff_d = {0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    public static boolean matchPattern(byte[] bytes, int[][] pattern) {
        next: for (int[] bits : pattern) {
            for (int pos = 0; pos < 64; pos++) {
                if (bits[pos] != -1 && bits[pos] != ((bytes[pos / 8] >> (7 - (pos % 8))) & 0x1)) {
                    continue next;
                }
            }
            return true;
        }
        return false;
    }

    public static int findMatch(byte[] bytes, int[][][] patterns, List<Integer> matched_ops) {
        for (int index = 0; index < patterns.length; index++) {
            if (!matched_ops.contains(index) && matchPattern(bytes, patterns[index])) {
                return index;
            }
        }
        return -1;
    }

    public static List<Object> sigCheck(int[][][] patterns, int[][] rules, byte[] content, int index, byte[] operation) {
        List<Integer> matched_ops = new ArrayList<>();
        matched_ops.add(0);
        List<byte[]> matched_bytes = new ArrayList<>();
        matched_bytes.add(operation);
        int pos = index + 8;
        while (matched_ops.size() < patterns.length) {
            byte[] nextop = new byte[8];
            System.arraycopy(content, pos, nextop, 0, 8);
            int op_pos = findMatch(nextop, patterns, matched_ops);
            if (op_pos != -1) {
                boolean found = false;
                for (int[] rule : rules) {
                    if (rule[0] == op_pos && matched_ops.contains(rule[1])) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    matched_ops.add(op_pos);
                    matched_bytes.add(nextop);
                    pos += 8;
                    continue;
                }
            }
            break;
        }
        if (matched_ops.size() == patterns.length) {
            List<Object> result = new ArrayList<>();
            result.add(index);
            result.add(matched_bytes);
            return result;
        }
        return null;
    }

    public static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    public static String byteslistToHex(List<byte[]> bytes) {
        StringBuilder hexBuilder = new StringBuilder();
        for (byte[] byteArray : bytes) {
            for (byte b : byteArray) {
                hexBuilder.append(String.format("%02x", b));
            }
        }
        return hexBuilder.toString().trim();
    }

    public static String format_byteslist(List<byte[]> bytes){
        boolean passed = false;
        StringBuilder hexBuilder = new StringBuilder();
        hexBuilder.append("[");
        for (byte[] byteArray : bytes) {
            if (passed) {
                hexBuilder.append(", ");
            } else {
                passed = true;
            }
            hexBuilder.append("'");
            for (byte b : byteArray) {
                hexBuilder.append(String.format("%02x", b));
            }
            hexBuilder.append("'");
        }
        hexBuilder.append("]");
        return hexBuilder.toString().trim();
    }

    public static String padbits(String bits){
        return "0000000000000000000000000000000000000000000000000000000000000000".substring(bits.length()) + bits;
    }

    public static byte[] padbytes(byte[] bytes){
        byte[] result = new byte[8];
        if (bytes.length > 8)
            System.arraycopy(bytes, bytes.length - 8, result, 0, 8);
        else
            System.arraycopy(bytes, 0, result, 8 - bytes.length, bytes.length);
        return result;
    }

    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Please provide path to offload.o and Android API level as arguments");
            System.exit(1);
        }
        System.out.println("Opening file '" + args[0] + "' for patching...");
        byte[] content = new byte[0];
        try {
            FileInputStream file = new FileInputStream(args[0]);
            content = new byte[(int) file.getChannel().size()];
            if (file.read(content) <= 0) {
                System.out.println("ERROR - file 'offload' is empty or can not be read");
                System.exit(1);
            }
            file.close();
        } catch (IOException e) {
            System.out.println("ERROR - file 'offload' does not exist");
            System.exit(1);
        }

        /*
            ram:00111110 07 04 00        ADD        R4,-0x1
                        00 ff ff
                        ff ff
            ram:00111118 6b 4a de        STXH       [R10 + -0x22=>local_22],R4
                        ff 00 00
                        00 00
            ram:00111120 57 04 00        AND        R4,0xffff
                        00 ff ff
                        00 00
        */
        int[][][] ip4_forward_opcodes = { {add_i0x1_d}, {stxh_so_d}, {and_i0xffff_d} };
        int[][] ip4_forward_rules = { {1, 2} };

        /*
            ram:00100738 bf 12 00        MOV        R2,R1
                        00 00 00
                        00 00
            ram:00100740 07 02 00        ADD        R2,-0x1
                        00 ff ff
                        ff ff
            ram:00100748 73 29 15        STXB       [R9 + 0x15],R2
        */
        int[][][] ip6_forward_opcodes = { {mov_s_d}, {add_i0x1_d}, {stxb_so_d} };
        int[][] ip6_forward_rules = { {1, 2} };

        List<List<Object>> ip4_forward_results = new ArrayList<>();
        List<List<Object>> ip6_forward_results = new ArrayList<>();

        for (int index = 0; index < content.length - 7; index += 8) {
            byte[] operation = new byte[] {content[index], content[index + 1], content[index + 2], content[index + 3], content[index + 4], content[index + 5], content[index + 6], content[index + 7]};

            if (matchPattern(operation, ip4_forward_opcodes[0])) {
                List<Object> result = sigCheck(ip4_forward_opcodes, ip4_forward_rules, content, index, operation);
                if (result != null) {
                    ip4_forward_results.add(result);
                }
            }

            if (matchPattern(operation, ip6_forward_opcodes[0])) {
                List<Object> result = sigCheck(ip6_forward_opcodes, ip6_forward_rules, content, index, operation);
                if (result != null) {
                    ip6_forward_results.add(result);
                }
            }
        }

        /*opc = bits.substring(0, 8);
        dst = bits.substring(8, 12);
        src = bits.substring(12, 16);
        off = bits.substring(16, 32);
        imm = bits.substring(32);*/

        System.out.println("\nPatching decrement in ip4_forward...");

        if (ip4_forward_results.size() >= 1) {
            for (List<Object> result : ip4_forward_results) {
                System.out.println("ip4_forward_decrement signature matched - 0x" + Integer.toHexString((int) result.get(0)) + " - " + format_byteslist((List<byte[]>) result.get(1)));
            }
        } else if (args[1].equals("30")) {
            System.out.println("No matches for ip4_forward, this is normal for Android 11");
        } else {
            System.out.println("ERROR - no matches for ip4_forward");
            System.exit(1);
        }

        int count = 1;
        for (List<Object> result : ip4_forward_results) {
            int offset = (int) result.get(0);
            List<byte[]> bytelist = (List<byte[]>) result.get(1);
            byte[] patchdata = new byte[bytelist.size() * 8];
            String bits = padbits(Long.toBinaryString(ByteBuffer.wrap(bytelist.get(0)).getLong()));
            String Rs = bits.substring(12, 16);
            System.arraycopy(padbytes(new BigInteger("010101110000" + Rs + "000000000000000000000000111111110000000000000000", 2).toByteArray()), 0, patchdata, 0, 8); // AND R?,0xff00
            System.arraycopy(padbytes(new BigInteger("010001110000" + Rs + "000000000000000001000000000000000000000000000000", 2).toByteArray()), 0, patchdata, 8, 8); // OR R?,0x40
            System.arraycopy(bytelist.get(1), 0, patchdata, 16, 8); // STXH [R? + -0x?],R?
            System.out.println("ip4_forward patch " + count + ":");
            System.out.println(byteslistToHex(bytelist));
            System.out.println(bytesToHex(patchdata));
            System.arraycopy(patchdata, 0, content, offset, patchdata.length);
            count += 1;
        }

        System.out.println("\nPatching decrement in ip6_forward...");

        if (ip6_forward_results.size() >= 1) {
            for (List<Object> result : ip6_forward_results) {
                System.out.println("ip6_forward_decrement signature matched - 0x" + Integer.toHexString((int) result.get(0)) + " - " + format_byteslist((List<byte[]>) result.get(1)));
            }
        } else {
            System.out.println("ERROR - no matches for ip6_forward");
            System.exit(1);
        }

        count = 1;
        for (List<Object> result : ip6_forward_results) {
            int offset = (int) result.get(0);
            List<byte[]> bytelist = (List<byte[]>) result.get(1);
            byte[] patchdata = new byte[bytelist.size() * 8];
            String bits = padbits(Long.toBinaryString(ByteBuffer.wrap(bytelist.get(0)).getLong()));
            String Rs = bits.substring(12, 16);
            System.arraycopy(bytelist.get(0), 0, patchdata, 0, 8); // MOV R2?,R?
            System.arraycopy(padbytes(new BigInteger("101101110000" + Rs + "000000000000000001000000000000000000000000000000", 2).toByteArray()), 0, patchdata, 8, 8); // MOV R?,0x?
            System.arraycopy(bytelist.get(2), 0, patchdata, 16, 8); // STXB [R? + 0x?],R?
            System.out.println("ip6_forward patch " + count + ":");
            System.out.println(byteslistToHex(bytelist));
            System.out.println(bytesToHex(patchdata));
            System.arraycopy(patchdata, 0, content, offset, patchdata.length);
            count += 1;
        }

        try (FileOutputStream file = new FileOutputStream(args[0] + ".patched")) {
            file.write(content);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
        System.out.println("\nFile patched! Saved to '" + args[0] + ".patched'");
        System.exit(0);
    }
}

import java.lang.System;
import java.lang.reflect.Array;
import java.lang.StringBuilder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.math.BigInteger;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/*
    Partial port of kallsyms_finder from vmlinux-to-elf
    https://github.com/marin-m/vmlinux-to-elf/blob/master/vmlinux_to_elf/kallsyms_finder.py
    https://github.com/marin-m/vmlinux-to-elf/blob/master/LICENSE

    Copyright (C) 2019  marin-m
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/
class kallsyms_finder {

    static boolean is_64_bits = true;
    static boolean is_big_endian = false;

    static boolean has_base_relative;
    static int kallsyms_token_table__offset;
    static int num_symbols;
    static int kallsyms_markers__offset;
    static int offset_table_element_size;
    static int kallsyms_names__offset;
    static int kallsyms_num_syms__offset;
    static int kallsyms_addresses_or_offsets__offset;
    static List<BigInteger> kernel_addresses;
    static Map<String, String> KallsymsSymbolType = new HashMap<>();

    private static void initialize() {
        // Seen in actual kernels
        kallsyms_finder.KallsymsSymbolType.put("ABSOLUTE", "A");
        kallsyms_finder.KallsymsSymbolType.put("BSS", "B");
        kallsyms_finder.KallsymsSymbolType.put("DATA", "D");
        kallsyms_finder.KallsymsSymbolType.put("RODATA", "R");
        kallsyms_finder.KallsymsSymbolType.put("TEXT", "T");
        kallsyms_finder.KallsymsSymbolType.put("WEAK_OBJECT_WITH_DEFAULT", "V");
        kallsyms_finder.KallsymsSymbolType.put("WEAK_SYMBOL_WITH_DEFAULT", "W");
        // Seen on nm's manpage
        kallsyms_finder.KallsymsSymbolType.put("SMALL_DATA", "G");
        kallsyms_finder.KallsymsSymbolType.put("INDIRECT_FUNCTION", "I");
        kallsyms_finder.KallsymsSymbolType.put("DEBUGGING", "N");
        kallsyms_finder.KallsymsSymbolType.put("STACK_UNWIND", "P");
        kallsyms_finder.KallsymsSymbolType.put("COMMON", "C");
        kallsyms_finder.KallsymsSymbolType.put("SMALL_BSS", "S");
        kallsyms_finder.KallsymsSymbolType.put("UNDEFINED", "U");
        kallsyms_finder.KallsymsSymbolType.put("UNIQUE_GLOBAL", "u");
        kallsyms_finder.KallsymsSymbolType.put("WEAK_OBJECT", "v");
        kallsyms_finder.KallsymsSymbolType.put("WEAK_SYMBOL", "w");
        kallsyms_finder.KallsymsSymbolType.put("STABS_DEBUG", "-");
        kallsyms_finder.KallsymsSymbolType.put("UNKNOWN", "?");
    }

    private static void assertion(boolean condition, String errorMessage) {
        if (!condition)
            throw new AssertionError(errorMessage);
    }

    private static byte[] pack(String format, long data) {
        assertion(format.length() == 2, "Invalid format string");
        assertion(format.charAt(0) == '<', "Invalid endianness");
        char specifier = format.charAt(1);
        Map<Character, Integer> fmt = new HashMap<>();
        fmt.put('H', 2);
        fmt.put('I', 4);
        fmt.put('Q', 8);
        ByteBuffer buffer = ByteBuffer.allocate(fmt.get(specifier)).order(ByteOrder.LITTLE_ENDIAN);
        if (specifier == 'H') {
            if (data != (short) data)
                throw new ArithmeticException("short overflow");
            buffer.putShort((short) data);
        } else if(specifier == 'I')
            buffer.putInt(Math.toIntExact(data));
        else if(specifier == 'Q')
            buffer.putLong(data);
        else
            throw new IllegalArgumentException("Invalid format string");
        return buffer.array();
    }

    private static BigInteger[] unpack_from(String format, byte[] data, int offset) {
        assertion(format.length() >= 2, "Invalid format string");
        assertion(format.charAt(0) == '<', "Invalid endianness");
        Map<Character, Integer> fmt = new HashMap<>();
        fmt.put('H', 2);
        fmt.put('h', 2);
        fmt.put('I', 4);
        fmt.put('i', 4);
        fmt.put('Q', 8);
        fmt.put('q', 8);
        int arraySize = 0;
        StringBuilder rep = new StringBuilder();
        for (int i = 1; i < format.length(); i++) {
            char specifier = format.charAt(i);
            if (fmt.containsKey(specifier)) {
                if (rep.length() == 0)
                    arraySize += 1;
                else
                    arraySize += Integer.parseInt(rep.toString());
            } else if (Character.isDigit(specifier))
                rep.append(specifier);
            else
                throw new IllegalArgumentException("Invalid format string");
        }
        BigInteger[] values = new BigInteger[arraySize];
        int position = 0;
        rep = new StringBuilder();
        for (int i = 1; i < format.length(); i++) {
            char specifier = format.charAt(i);
            int j;
            int size;
            if (!fmt.containsKey(specifier)) {
                rep.append(specifier);
                continue;
            }
            size = fmt.get(specifier);
            int count;
            if (rep.length() == 0)
                count = 1;
            else
                count = Integer.parseInt(rep.toString());
            for (j = 0; j < count; j++)
                if (Character.isLowerCase(specifier))
                    values[position + j] = new BigInteger(swapEndianness(Arrays.copyOfRange(data, offset + position + (j * size), offset + position + (j * size) + size)));
                else
                    values[position + j] = new BigInteger(1, swapEndianness(Arrays.copyOfRange(data, offset + position + (j * size), offset + position + (j * size) + size)));
            position += j;
            rep = new StringBuilder();
        }
        return values;
    }

    private static int find(byte[] source, byte[] target, int start) {
        for (int i = start; i <= source.length - target.length; i++) {
            if (source[i] == target[0]) {
                int j;
                for (j = 1; j < target.length; j++) {
                    if (source[i + j] != target[j])
                        break;
                }
                if (j == target.length)
                    return i;
            }
        }
        return -1;
    }

    private static int rfind(byte[] source, byte[] target, int start, int end) {
        if (source == null || target == null || start < 0 || end < 0 || start > source.length) {
            throw new IllegalArgumentException("Invalid input");
        }
        if (target.length == 0) {
            return end;
        }
        int result = -1;
        for (int i = end; i >= start; i--) {
            if (source[i] == target[target.length - 1]) {
                boolean found = true;
                for (int j = target.length - 2; j >= 0; j--) {
                    if (i - target.length + 1 + j < 0 || source[i - target.length + 1 + j] != target[j]) {
                        found = false;
                        break;
                    }
                }
                if (found) {
                    result = i - target.length + 1;
                    break;
                }
            }
        }
        return result;
    }

    private static byte[] swapEndianness(byte[] byteArray) {
        assertion(byteArray.length >= 0 && byteArray.length % 2 == 0, "Invalid byteArray");
        for (int i = 0; i < byteArray.length / 2; i++) {
            byte temp = byteArray[i];
            byteArray[i] = byteArray[byteArray.length - i - 1];
            byteArray[byteArray.length - i - 1] = temp;
        }
        return byteArray;
    }

    private static void find_kallsyms_token_table(byte[] kernel_img) {

        /*
            kallsyms_token_table is an array of 256 variable length null-
            terminated string fragments. Positions which correspond to
            an ASCII character which is used in at least one symbol
            contain the corresponing character (1), other position contain
            a string fragment chosen by the compression algorithm (2).

            Hence, characters [0-9] and [a-z] are always present at their
            respective positions, but ":" (which comes after "9") never does.

            (1) See "insert_real_symbols_in_table" of "scripts/kallsyms.c"
            (2) See "optimize_result" of "scripts/kallsyms.c"
        */

        int position = 0;

        List<Integer> candidates_offsets = new ArrayList<>(); // offsets at which sequence_to_find was found
        List<Integer> candidates_offsets_followed_with_ascii = new ArrayList<>(); // variant with an higher certainty

        //sequence_to_find = b''.join(b'%c\0' % i for i in range(ord('0'), ord('9') + 1))
        byte[] sequence_to_find = new byte[]{(byte) 0x30, (byte) 0x00, (byte) 0x31, (byte) 0x00, (byte) 0x32, (byte) 0x00, (byte) 0x33, (byte) 0x00, (byte) 0x34, (byte) 0x00, (byte) 0x35, (byte) 0x00, (byte) 0x36, (byte) 0x00, (byte) 0x37, (byte) 0x00, (byte) 0x38, (byte) 0x00, (byte) 0x39, (byte) 0x00};

        byte[][] sequences_to_avoid = {
                ":\0".getBytes(),
                "\0\0".getBytes(),
                "\0\1".getBytes(),
                "\0\2".getBytes(),
                "ASCII\0".getBytes()
        };

        while (true) {
            position = find(kernel_img, sequence_to_find, position + 1);
            if (position == -1)
                break;
            boolean flag = true;
            int pos = 0;
            for (byte[] seq : sequences_to_avoid) {
                pos = position + sequence_to_find.length;
                if (Arrays.equals(Arrays.copyOfRange(kernel_img, pos, pos + seq.length), seq)) {
                    flag = false;
                    break;
                }
            }
            if (flag) {
                candidates_offsets.add(position);
                if (Character.isLetterOrDigit((char) (Array.getByte(kernel_img, pos) & 0xFF))) {
                    candidates_offsets_followed_with_ascii.add(position);
                }
            }
        }

        if (candidates_offsets.size() != 1) {
            if (candidates_offsets_followed_with_ascii.size() == 1) {
                candidates_offsets = candidates_offsets_followed_with_ascii;
            } else if (candidates_offsets.size() == 0) {
                throw new RuntimeException(String.format("%d candidates for kallsyms_token_table in kernel image", candidates_offsets.size()));
            } else {
                throw new RuntimeException(String.format("%d candidates for kallsyms_token_table in kernel image", candidates_offsets.size()));
            }
        }

        position = candidates_offsets.get(0);

        // Get back to the beginning of the table
        int current_index_in_array = (int) '0';

        position -= 1;
        assertion(position >= 0 && kernel_img[position] == 0, "Invalid position");

        for (int tokens_backwards = 0; tokens_backwards < current_index_in_array; tokens_backwards++) {
            for (int chars_in_token_backwards = 0; chars_in_token_backwards < 50; chars_in_token_backwards++) {

                position -= 1;
                assertion(position >= 0, "position must be greater or equal to 0");

                // (caveat: we may overlap on "kallsyms_markers" for the
                // last entry, so also check for high-range characters)
                if (Array.getByte(kernel_img, position) == 0 || kernel_img[position] > (int) 'z') {
                    break;
                }

                if (chars_in_token_backwards >= 50 -1) {
                    throw new RuntimeException("This structure is not a kallsyms_token_table");
                }
            }
        }
        position += 1;
        position += Math.floorMod(-position, 4);

        kallsyms_finder.kallsyms_token_table__offset = position;

        System.out.printf("[+] Found kallsyms_token_table at file offset 0x%08x%n", kallsyms_finder.kallsyms_token_table__offset);
    }

    // NOTE: Removed code for uncompressed_kallsyms
    private static List<String> get_token_table(byte[] kernel_img) {
        List<String> tokens = new ArrayList<>();
        // Parse symbol name tokens
        int position = kallsyms_finder.kallsyms_token_table__offset;
        for (int num_token = 0; num_token < 256; num_token++) {
            StringBuilder token = new StringBuilder();
            while (kernel_img[position] != 0) {
                token.append((char) kernel_img[position]);
                position += 1;
            }
            tokens.add(token.toString());
            position += 1;
        }
        return tokens;
    }

    private static void find_kallsyms_markers(byte[] kernel_img) {

        /*
            kallsyms_markers contains one offset in kallsyms_names for each
            1 in 256 entries of it. Offsets are stored as either ".long"
            (a Gnu AS type that corresponds for example to 4 bytes in
            x86_64) since kernel v4.20, either as the maximum register
            byte of the system (the C "long" type) on older kernels.
            Remember about the size of this field for later.
            The first index is always 0, it is sorted, and it is aligned.
        */

        // Try possible sizes for the table element (long type)
        for (int table_element_size : new int[]{8, 4, 2}) {
            int position = kallsyms_finder.kallsyms_token_table__offset;

            String endianness_marker = kallsyms_finder.is_big_endian ? ">" : "<";

            Map<Integer, String> fmt = new HashMap<>();
            fmt.put(2, "H");
            fmt.put(4, "I");
            fmt.put(8, "Q");
            String long_size_marker = fmt.get(table_element_size);

            // Search for start of kallsyms_markers given first element is 0 and it is sorted
            for (int i_ = 0; i_ < 32; i_++) {
                position = rfind(kernel_img, new byte[table_element_size], 0, position);
                position -= position % table_element_size;

                BigInteger[] entries = unpack_from(endianness_marker + '4' + long_size_marker, kernel_img, position);

                if (!entries[0].equals(BigInteger.valueOf(0)))
                    continue;
                int entriesLength = entries.length;
                int i;
                for (i = 1; i < entriesLength; i++) {
                    if (entries[i - 1].add(BigInteger.valueOf(0x200)).compareTo(entries[i]) > 0 || entries[i - 1].add(BigInteger.valueOf(0x4000)).compareTo(entries[i]) < 0) {
                        break;
                    }
                }
                if (i == entriesLength) {
                    System.out.printf("[+] Found kallsyms_markers at file offset 0x%08x%n", position);
                    kallsyms_finder.kallsyms_markers__offset = position;
                    kallsyms_finder.offset_table_element_size = table_element_size;
                    return;
                }
            }
        }
        throw new RuntimeException("Could not find kallsyms_markers");
    }

    private static void find_kallsyms_names(byte[] kernel_img) {

        int position = kallsyms_finder.kallsyms_markers__offset;

        // Approximate the position of kallsyms_names based on the
        // last entry of "kallsyms_markers" - we'll determine the
        // precise position in the next method

        String endianness_marker = kallsyms_finder.is_big_endian ? ">" : "<";
        Map<Integer, String> fmt = new HashMap<>();
        fmt.put(2, "H");
        fmt.put(4, "I");
        fmt.put(8, "Q");
        String long_size_marker = fmt.get(kallsyms_finder.offset_table_element_size);

        BigInteger[] kallsyms_markers_entries = unpack_from(endianness_marker + "3000" + long_size_marker, kernel_img, kallsyms_finder.kallsyms_markers__offset);

        for (int i = 1; i < kallsyms_markers_entries.length; i++) {
            BigInteger curr = kallsyms_markers_entries[i];
            BigInteger last = kallsyms_markers_entries[i-1];
            if (last.add(BigInteger.valueOf(0x200)).compareTo(curr) > 0 || last.add(BigInteger.valueOf(0x4000)).compareTo(curr) < 0) {
                kallsyms_markers_entries = Arrays.copyOfRange(kallsyms_markers_entries, 0, i);
                break;
            }
        }

        BigInteger[] entry = Arrays.copyOfRange(kallsyms_markers_entries, 0, kallsyms_markers_entries.length);
        BigInteger last_kallsyms_markers_entry = BigInteger.valueOf(0);
        for (int i = entry.length - 1; i >= 0; i--) {
            if (!entry[i].equals(BigInteger.valueOf(0))) {
                last_kallsyms_markers_entry = entry[i];
                break;
            }
        }

        if (last_kallsyms_markers_entry.compareTo(BigInteger.valueOf(Integer.MAX_VALUE)) > 0 || last_kallsyms_markers_entry.compareTo(BigInteger.valueOf(Integer.MIN_VALUE)) < 0)
            throw new RuntimeException("last_kallsyms_markers_entry out of range of Integer");
        position -= last_kallsyms_markers_entry.intValue();
        position += Math.floorMod(-position, kallsyms_finder.offset_table_element_size);

        assertion(position > 0, "position must be greater than 0");

        kallsyms_finder.kallsyms_names__offset = position;

        // Guessing continues in the function below (in order to handle the
        // absence of padding)
    }

    private static void find_kallsyms_num_syms(byte[] kernel_img) {

        int needle = -1;

        List<String> token_table = kallsyms_finder.get_token_table(kernel_img);
        List<String> possible_symbol_types = new ArrayList<>();
        for (Map.Entry<String, String> entry : kallsyms_finder.KallsymsSymbolType.entrySet())
            possible_symbol_types.add(entry.getValue());

        List<Integer> dp = new ArrayList<>();
        int position;

        while (needle == -1) {

            position =  kallsyms_finder.kallsyms_names__offset;

            /*
              Check whether this looks like the correct symbol
              table, first depending on the beginning of the
              first symbol (as this is where an uncertain gap
              of 4 padding bytes may be present depending on
              versions or builds), then thorough the whole
              table. Raise an issue further in the code (in
              another function) if an exotic kind of symbol is
              found somewhere else than in the first entry.
            */

            int first_token_index_of_first_name = kernel_img[position + 1] &0xff;
            String first_token_of_first_name = token_table.get(first_token_index_of_first_name);

            if (!("uvw".contains(first_token_of_first_name.toLowerCase().substring(0, 1)) && possible_symbol_types.contains(first_token_of_first_name.toLowerCase())) &&
                    !possible_symbol_types.contains(first_token_of_first_name.toUpperCase().substring(0, 1))) {
                kallsyms_finder.kallsyms_names__offset -= 4;
                if (kallsyms_finder.kallsyms_names__offset < 0) {
                    throw new RuntimeException("Could not find kallsyms_names");
                }
                continue;
            }

            /*
              Each entry in the symbol table starts with a u8 size followed by the contents.
              The table ends with an entry of size 0, and must lie before kallsyms_markers.
              This for loop uses a bottom-up DP approach to calculate the numbers of symbols without recalculations.
              dp[i] is the length of the symbol table given a starting position of "kallsyms_markers - i"
              If the table position is invalid, i.e. it reaches out of bounds, the length is marked as -1.
              The loop ends with the number of symbols for the current position in the last entry of dp.
            */

            for (int i = dp.size(); i < kallsyms_finder.kallsyms_markers__offset - position + 1; i++) {
                int symbol_size = Byte.toUnsignedInt(kernel_img[kallsyms_finder.kallsyms_markers__offset - i]);
                int next_i = i - symbol_size - 1;
                if (symbol_size == 0) {  // Last entry of the symbol table
                    dp.add(0);
                } else if (next_i < 0 || dp.get(next_i) == -1) {  // If table would exceed kallsyms_markers, mark as invalid
                    dp.add(-1);
                } else {
                    dp.add(dp.get(next_i) + 1);
                }
            }
            int num_symbols = dp.get(dp.size() - 1);

            if (num_symbols < 256) {
                kallsyms_finder.kallsyms_names__offset -= 4;
                if (kallsyms_finder.kallsyms_names__offset < 0) {
                    throw new RuntimeException("Could not find kallsyms_names");
                }
                continue;
            }

            kallsyms_finder.num_symbols = num_symbols;

            // Find the long or PTR (it should be the same size as a kallsyms_marker
            // entry) encoding the number of symbols right before kallsyms_names

            String endianness_marker = kallsyms_finder.is_big_endian ? ">" : "<";
            Map<Integer, String> fmt = new HashMap<>();
            fmt.put(2, "H");
            fmt.put(4, "I");
            fmt.put(8, "Q");
            String long_size_marker = fmt.get(kallsyms_finder.offset_table_element_size);

            int MAX_ALIGNMENT = 256;

            byte[] encoded_num_symbols = pack(endianness_marker + long_size_marker, (long) num_symbols);

            needle = rfind(kernel_img, encoded_num_symbols, Math.max(0, kallsyms_finder.kallsyms_names__offset - MAX_ALIGNMENT - 20), kallsyms_finder.kallsyms_names__offset);

            // There may be no padding between kallsyms_names and kallsyms_num_syms, if the alignment is already correct: in this case: try other offsets for "kallsyms_names"
            if (needle == -1) {
                kallsyms_finder.kallsyms_names__offset -= 4;
                if (kallsyms_finder.kallsyms_names__offset < 0) {
                    throw new RuntimeException("Could not find kallsyms_names");
                }
            }
        }

        System.out.printf("[+] Found kallsyms_names at file offset 0x%08x%n", kallsyms_finder.kallsyms_names__offset);

        position = needle;
        kallsyms_finder.kallsyms_num_syms__offset = position;

        System.out.printf("[+] Found kallsyms_num_syms at file offset 0x%08x%n", position);
    }

    // This deviates far from the original function, I can't just assume has_base_relative and return bad addresses
    private static void find_kallsyms_addresses_or_symbols(byte[] kernel_img) {

        boolean likely_is_64_bits = kallsyms_finder.is_64_bits;
        cont: for (boolean has_base_relative : new boolean[]{false, true}) {

            int position = kallsyms_finder.kallsyms_num_syms__offset;

            int address_byte_size = likely_is_64_bits ? 8 : kallsyms_finder.offset_table_element_size;
            int offset_byte_size = Math.min(4, kallsyms_finder.offset_table_element_size); // Size of an assembly ".long"

            // Go right after the previous address
            while (true) {
                assertion(position > 0, "position must be greater than 0"); // >= self.offset_table_element_size // Needed?
                byte[] previous_word = Arrays.copyOfRange(kernel_img, position - address_byte_size, position);

                if (!Arrays.equals(previous_word, new byte[address_byte_size])) {
                    break;
                }
                position -= address_byte_size;
            }

            if (has_base_relative) {
                kallsyms_finder.has_base_relative = true;
                position -= kallsyms_finder.num_symbols * offset_byte_size;
            } else {
                kallsyms_finder.has_base_relative = false;
                position -= kallsyms_finder.num_symbols * address_byte_size;
            }
            kallsyms_finder.kallsyms_addresses_or_offsets__offset = position;

            // Check the obtained values
            String endianness_marker = kallsyms_finder.is_big_endian ? ">" : "<";
            String long_size_marker;
            if (kallsyms_finder.has_base_relative) {
                Map<Integer, String> fmt = new HashMap<>();
                fmt.put(2, "h");
                fmt.put(4, "i");
                long_size_marker = fmt.get(offset_byte_size); // offsets may be negative, contrary to addresses
            } else {
                Map<Integer, String> fmt = new HashMap<>();
                fmt.put(2, "H");
                fmt.put(4, "I");
                fmt.put(8, "Q");
                long_size_marker = fmt.get(address_byte_size);
            }

            // Parse symbols addresses
            List<BigInteger> tentative_addresses_or_offsets = Arrays.asList(unpack_from(endianness_marker + kallsyms_finder.num_symbols + long_size_marker, kernel_img, kallsyms_finder.kallsyms_addresses_or_offsets__offset));

            if (!kallsyms_finder.has_base_relative) {
                // Assume kallsyms_addresses is monotonous and check that the offsets are sequential.
                BigInteger lastoffset = BigInteger.ZERO;
                for (BigInteger offset : tentative_addresses_or_offsets) {
                    if (offset.compareTo(lastoffset) < 0) {
                        continue cont;
                    }
                    lastoffset = offset;
                }
            }

            System.out.printf("[+] Found %s at file offset 0x%08x%n", kallsyms_finder.has_base_relative ? "kallsyms_offsets" : "kallsyms_addresses", position);

            kallsyms_finder.kernel_addresses = tentative_addresses_or_offsets;
            break; // DEBUG
        }
    }

    public static void process(byte[] content) {
        initialize();

        find_kallsyms_token_table(content);
        find_kallsyms_markers(content);
        find_kallsyms_names(content);
        find_kallsyms_num_syms(content);
        find_kallsyms_addresses_or_symbols(content);
    }
}


public class kernel_patcher {

    // DDI0487_I_a_a-profile_architecture_reference_manual.pdf

    // C6.2.2 ADCS
    static int[] adcs_32 = {0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] adcs_64 = {1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.4 ADD (immediate)
    static int[] add_i_32 = {0, 0, 0, 1, 0, 0, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] add_i_64 = {1, 0, 0, 1, 0, 0, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.5 ADD (shifted register)
    static int[] add_sr_32 = {0, 0, 0, 0, 1, 0, 1, 1, -1, -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] add_sr_64 = {1, 0, 0, 0, 1, 0, 1, 1, -1, -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.12 AND (immediate)
    static int[] and_i_32 = {0, 0, 0, 1, 0, 0, 1, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] and_i_64 = {1, 0, 0, 1, 0, 0, 1, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.34 BL
    static int[] bl = {1, 0, 0, 1, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.54 CINC
    static int[] cinc_32 = {0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] cinc_64 = {1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.61 CMN (shifted register)
    static int[] cmn_sr_32 = {0, 0, 1, 0, 1, 0, 1, 1, -1, -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 1, 1};
    static int[] cmn_sr_64 = {1, 0, 1, 0, 1, 0, 1, 1, -1, -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 1, 1};

    // C6.2.64 CMP (shifted register)
    static int[] cmp_sr_32 = {0, 1, 1, 0, 1, 0, 1, 1, -1, -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 1, 1};
    static int[] cmp_sr_64 = {1, 1, 1, 0, 1, 0, 1, 1, -1, -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 1, 1};

    // C6.2.164 LDP - Signed offset
    static int[] ldp_so = {-1, 0, 1, 0, 1, 0, 0, 1, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.170 LDRB (immediate) - Unsigned offset
    static int[] ldrb_i_uo = {0, 0, 1, 1, 1, 0, 0, 1, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.172 LDRH (immediate) - Unsigned offset
    static int[] ldrh_i_uo = {0, 1, 1, 1, 1, 0, 0, 1, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.220 MOV (to/from SP)
    static int[] mov_sp_32 = {0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] mov_sp_64 = {1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.222 MOV (wide immediate)
    static int[] mov_wi_32 = {0, 1, 0, 1, 0, 0, 1, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] mov_wi_64 = {1, 1, 0, 1, 0, 0, 1, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.224 MOV (register)
    static int[] mov_r_32 = {0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1};
    static int[] mov_r_64 = {1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1};

    // C6.2.321 STP - Pre-index
    static int[] stp_bi_32 = {0, 0, 1, 0, 1, 0, 0, 1, 1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] stp_bi_64 = {1, 0, 1, 0, 1, 0, 0, 1, 1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.322 STR (immediate) - Unsigned offset
    static int[] str_i_uo_32 = {1, 0, 1, 1, 1, 0, 0, 1, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] str_i_uo_64 = {1, 1, 1, 1, 1, 0, 0, 1, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.324 STRB (immediate) - Unsigned offset
    static int[] strb_i_uo = {0, 0, 1, 1, 1, 0, 0, 1, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.326 STRH (immediate) - Unsigned offset
    static int[] strh_i_uo = {0, 1, 1, 1, 1, 0, 0, 1, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.357 SUB (immediate)
    static int[] sub_i_32 = {0, 1, 0, 1, 0, 0, 0, 1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] sub_i_64 = {1, 1, 0, 1, 0, 0, 0, 1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.245 PACIA, PACIA1716, PACIASP, PACIAZ, PACIZA
    static int[] paciasp = {1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1};

    // ----------------------------------------------------

    // and w?,w?,#0xf
    static int[] and_i_32__f = { 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // strh wzr,[x?, #0x?]
    static int[] strh_i_uo__wzr = { 0, 1, 1, 1, 1, 0, 0, 1, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 1, 1 };

    // mov w?,#0xfffd
    static int[] mov_wi_32_fffd = {0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, -1, -1, -1, -1, -1};

    // cinc w?,w?,hi
    static int[] cinc_32_hi = {0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, -1, -1, -1, -1, -1, 1, 0, 0, 1, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // sub w?,w?,#0x1
    static int[] sub_i_32_1 = {0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // add w?,w?,#0x1
    static int[] add_i_32_1 = {0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // ----------------------------------------------------

    static int[] matchall = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    public static boolean matchPattern(byte[] bytes, int[][] pattern) {
        next: for (int[] bits : pattern) {
            for (int pos = 0; pos < 32; pos++) {
                if (bits[pos] != -1 && bits[pos] != ((bytes[(31 - pos) / 8] >> (31 - pos) % 8) & 0x1)) {
                    continue next;
                }
            }
            return true;
        }
        return false;
    }

    public static int findMatch(byte[] bytes, int[][][] patterns, List<Integer> matched_ops) {
        for (int index = 0; index < patterns.length; index++) {
            if (!matched_ops.contains(index) && matchPattern(bytes, patterns[index])) {
                return index;
            }
        }
        return -1;
    }

    public static List<Object> sigCheck(int[][][] patterns, int[][] rules, byte[] content, int index, byte[] operation, kallsyms_finder kallsyms, boolean isExported) {
        List<Integer> matched_ops = new ArrayList<>();
        matched_ops.add(0);
        List<byte[]> matched_bytes = new ArrayList<>();
        matched_bytes.add(operation);
        int pos = index + 4;
        while (matched_ops.size() < patterns.length) {
            byte[] nextop = new byte[4];
            System.arraycopy(content, pos, nextop, 0, 4);
            int op_pos = findMatch(nextop, patterns, matched_ops);
            if (op_pos != -1) {
                boolean found = false;
                for (int[] rule : rules) {
                    if (rule[0] == op_pos && matched_ops.contains(rule[1])) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    matched_ops.add(op_pos);
                    matched_bytes.add(nextop);
                    pos += 4;
                    continue;
                }
            }
            break;
        }

        BigInteger offset = BigInteger.valueOf(index);
        if (!kallsyms.has_base_relative) { // add VA offset if not relative, might not always work, idk
            offset = offset.add(kallsyms.kernel_addresses.get(0));
        }
        if (matched_ops.size() == patterns.length && (!isExported || kallsyms.kernel_addresses.contains(offset))) {
            List<Object> result = new ArrayList<>();
            result.add(index);
            result.add(matched_bytes);
            return result;
        }
        return null;
    }

    public static String calcBranch(int pc, int dst) {
        int diff = dst - pc;
        String result = null;
        if (diff > 0 && diff < 33554432) {
            result = String.format("%26s", Integer.toBinaryString(diff >> 2)).replace(' ', '0');
        } else if (diff < 0 && diff > -33554432) {
            result = String.format("%26s", Integer.toBinaryString((diff >> 2) + (1 << 26))).replace(' ', '0');
        } else {
            System.out.println("ERROR - Branch out of bounds");
            System.exit(1);
        }
        return result;
    }

    public static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    public static String byteslistToHex(List<byte[]> bytes) {
        StringBuilder hexBuilder = new StringBuilder();
        for (byte[] byteArray : bytes) {
            for (byte b : byteArray) {
                hexBuilder.append(String.format("%02x", b));
            }
        }
        return hexBuilder.toString().trim();
    }

    public static String formatBytesList(List<byte[]> bytes){
        boolean passed = false;
        StringBuilder hexBuilder = new StringBuilder();
        hexBuilder.append("[");
        for (byte[] byteArray : bytes) {
            if (passed) {
                hexBuilder.append(", ");
            } else {
                passed = true;
            }
            hexBuilder.append("'");
            for (byte b : byteArray) {
                hexBuilder.append(String.format("%02x", b));
            }
            hexBuilder.append("'");
        }
        hexBuilder.append("]");
        return hexBuilder.toString().trim();
    }

    public static byte[] littleEndian(byte[] value) {
        final int length = value.length;
        byte[] result = new byte[length];
        for(int i = 0; i < length; i++) {
            result[length - i - 1] = value[i];
        }
        return result;
    }

    public static String padbits(String bits){
        return "00000000000000000000000000000000".substring(bits.length()) + bits;
    }

    public static byte[] padbytes(byte[] bytes){
        byte[] result = new byte[4];
        if (bytes.length > 4)
            System.arraycopy(bytes, bytes.length - 4, result, 0, 4);
        else
            System.arraycopy(bytes, 0, result, 4 - bytes.length, bytes.length);
        return result;
    }

    public static boolean startsWith(byte[] source, byte[] target) {
        if (source.length < target.length)
            return false;

        for (int i = 0; i < target.length; i++) {
            if (source[i] != target[i])
                return false;
        }
        return true;
    }

    public static void main(String[] args) {
        System.out.println("Opening file 'kernel' for patching...");
        byte[] content = new byte[0];
        try {
            FileInputStream file = new FileInputStream("kernel");
            content = new byte[(int) file.getChannel().size()];
            if (file.read(content) <= 0) {
                System.out.println("ERROR - file 'kernel' is empty or can not be read");
                System.exit(1);
            }
            file.close();
        } catch (IOException e) {
            System.out.println("ERROR - file 'kernel' does not exist");
            System.exit(1);
        }

        // TODO: map relation with stack between instructions for more accurate matches
        // TODO: better account for fixed arguments, static defs are lame

        byte[] head = new byte[0];
        byte[] tail = new byte[0];
        if (startsWith(content, "UNCOMPRESSED_IMG".getBytes())) {
            head = Arrays.copyOfRange(content, 0, 20);
            int dtb_offset_le = ByteBuffer.wrap(content, 16, 4).order(ByteOrder.LITTLE_ENDIAN).getInt();
            tail = Arrays.copyOfRange(content, 20 + dtb_offset_le, content.length);
            content = Arrays.copyOfRange(content, 20, 20 + dtb_offset_le);
        }

        kallsyms_finder kallsyms = new kallsyms_finder();
        kallsyms.process(content);

        // NOTE: Patterns are assumed to be sequential for optimization and rules must be too. (eg. {2, 1} is invalid)
        // NOTE: For this same reason, matchall must be at the end of a pattern.
        // NOTE: The first definition in a pattern is always static so rules should never reference it. (eg. {0, 1} is invalid)

        /* fc011442e20 3f 23 03 d5     paciasp */
        //int[][][] pointer_authentication = { {paciasp} };

        /* f8009162f9c fd 7b be a9     stp        x29,x30,[sp, #local_20]!
           f8009162fa0 f3 0b 00 f9     str        x19,[sp, #local_10]
           f8009162fa4 fd 03 00 91     mov        x29,sp
           f8009162fa8 f3 03 00 aa     mov        x19,x0
           f8009162fac 64 f4 bc 97     bl         _mcount */
        //int[][][] profiling_stub = { {stp_bi_64}, {str_i_uo_64}, {mov_sp_64}, {mov_r_64}, {bl} };

        /* f80093a8f40 1f 14 00 79     strh       wzr,[x0, #0xa]
           f80093a8f44 08 40 00 91     add        x8,x0,#0x10
           f80093a8f48 09 00 40 39     ldrb       w9,[x0]
           f80093a8f4c 0a 2c 40 a9     ldp        x10,x11,[x0]
           f80093a8f50 2c 0d 00 12     and        w12,w9,#0xf
           f80093a8f54 7f 01 0a ab     cmn        x11,x10
           f80093a8f58 49 01 0b ba     adcs       x9,x10,x11
           f80093a8f5c 8a 0d 00 51     sub        w10,w12,#0x3 */
        //int[][][] ip_send_check_base1 = { {strh_i_uo}, {ldrb_i_uo}, {ldp_so}, {add_i_64}, {and_i_32}, {cmn_sr_64}, {adcs_64}, {sub_i_32} };

        /* f80090d4680 1f 14 00 79     strh       wzr,[x0, #0xa]
           f80090d4684 08 40 00 91     add        x8,x0,#0x10
           f80090d4688 0a 00 40 39     ldrb       w10,[x0]
           f80090d468c 09 30 40 a9     ldp        x9,x12,[x0]
           f80090d4690 4d 11 00 11     add        w13,w10,#0x4
           f80090d4694 9f 01 09 ab     cmn        x12,x9
           f80090d4698 4b 0d 00 12     and        w11,w10,#0xf
           f80090d469c 2a 01 0c ba     adcs       x10,x9,x12
           f80090d46a0 a9 09 00 12     and        w9,w13,#0x7
           f80090d46a4 6e 15 00 51     sub        w14,w11,#0x5 */
        //int[][][] ip_send_check_base2 = { {strh_i_uo}, {ldrb_i_uo}, {ldp_so}, {add_i_64}, {add_i_32}, {and_i_32}, {and_i_32}, {cmn_sr_64}, {adcs_64}, {sub_i_32} };

        // NOTE: The matchall ops in this pattern may avoid some false negatives, but greatly increases false positives.
        int[][][] ip_send_check_opcodes1 = { {paciasp}, {stp_bi_64}, {str_i_uo_64}, {mov_sp_64}, {mov_r_64}, {bl}, {strh_i_uo__wzr}, {ldrb_i_uo}, {ldp_so}, {add_i_64}, {and_i_32__f}, {cmn_sr_64}, {adcs_64}, {sub_i_32}, {matchall}, {matchall} };
        int[][] ip_send_check_rules1 = { {1, 5}, {2, 5}, {3, 5}, {4, 5}, {5, 6}, {6, 7}, {6, 8}, {6, 9}, {6, 10}, {6, 11}, {6, 12}, {6, 13}, {8, 11}, {9, 12}, {9, 13}, {11, 14}, {12, 13} };
        int[][][] ip_send_check_opcodes2 = { {paciasp}, {strh_i_uo__wzr}, {ldrb_i_uo}, {ldp_so}, {add_i_64}, {and_i_32__f}, {cmn_sr_64}, {adcs_64}, {sub_i_32}, {matchall}, {matchall} };
        int[][] ip_send_check_rules2 = { {1, 2}, {1, 3}, {1, 4}, {1, 5}, {1, 6}, {1, 7}, {1, 8}, {2, 5}, {3, 6}, {3, 7}, {5, 8}, {6, 7} };
        int[][][] ip_send_check_opcodes3 = { {stp_bi_64}, {str_i_uo_64}, {mov_sp_64}, {mov_r_64}, {bl}, {strh_i_uo__wzr}, {ldrb_i_uo}, {ldp_so}, {add_i_64}, {and_i_32__f}, {cmn_sr_64}, {adcs_64}, {sub_i_32}, {matchall}, {matchall} };
        int[][] ip_send_check_rules3 = { {1, 4}, {2, 4}, {3, 4}, {4, 5}, {5, 6}, {5, 7}, {5, 8}, {5, 9}, {5, 10}, {5, 11}, {5, 12}, {7, 10}, {8, 11}, {8, 12}, {10, 13}, {11, 12} };
        int[][][] ip_send_check_opcodes4 = { {strh_i_uo__wzr}, {ldrb_i_uo}, {ldp_so}, {add_i_64}, {and_i_32__f}, {cmn_sr_64}, {adcs_64}, {sub_i_32}, {matchall}, {matchall} };
        int[][] ip_send_check_rules4 = { {1, 4}, {2, 5}, {2, 6}, {4, 7}, {5, 6} };

        /*fc010f485ec 69 6a 41 79     ldrh       w9,[x19, #0xb4]
        fc010f485f0 aa ff 9f 52     mov        w10,#0xfffd
        fc010f485f4 16 01 09 8b     add        x22,x8,x9
        fc010f485f8 c8 16 40 79     ldrh       w8,[x22, #0xa]
        fc010f485fc c9 22 40 39     ldrb       w9,[x22, #0x8]
        fc010f48600 1f 01 0a 6b     cmp        w8,w10
        fc010f48604 08 95 88 1a     cinc       w8,w8,hi
        fc010f48608 29 05 00 51     sub        w9,w9,#0x1
        fc010f4860c 08 05 00 11     add        w8,w8,#0x1
        fc010f48610 c8 16 00 79     strh       w8,[x22, #0xa]
        fc010f48614 c9 22 00 39     strb       w9,[x22, #0x8]*/
        int[][][] ip_decrease_ttl_opcodes = { {ldrh_i_uo}, {mov_wi_32_fffd}, {add_sr_64}, {ldrh_i_uo}, {ldrb_i_uo}, {cmp_sr_32}, {cinc_32_hi}, {sub_i_32_1}, {add_i_32_1}, {strh_i_uo}, {strb_i_uo} };
        int[][] ip_decrease_ttl_rules = { {1, 5}, {3, 5}, {3, 6}, {3, 8}, {3, 9}, {4, 7}, {4, 10}, {5, 6}, {6, 8}, {6, 9}, {7, 10}, {8, 9} };

        /*f8008f42430 69 c2 41 79     ldrh       w9,[x19, #0xe0]
        f8008f42434 08 01 09 8b     add        x8,x8,x9
        f8008f42438 09 1d 40 39     ldrb       w9,[x8, #0x7]
        f8008f4243c 29 05 00 51     sub        w9,w9,#0x1
        f8008f42440 09 1d 00 39     strb       w9,[x8, #0x7]*/
        int[][][] ip6_forward_opcodes = { {ldrh_i_uo}, {add_sr_64}, {ldrb_i_uo}, {sub_i_32_1}, {strb_i_uo} };
        int[][] ip6_forward_rules = { {1, 2}, {2, 3}, {3, 4} };

        List<List<Object>> ip_send_check_results1 = new ArrayList<>();
        List<List<Object>> ip_send_check_results2 = new ArrayList<>();
        List<List<Object>> ip_send_check_results3 = new ArrayList<>();
        List<List<Object>> ip_send_check_results4 = new ArrayList<>();
        List<List<Object>> ip_send_check_results = new ArrayList<>();
        List<List<Object>> ip_decrease_ttl_results = new ArrayList<>();
        List<List<Object>> ip6_forward_results = new ArrayList<>();
        for (int index = 0; index < content.length - 3; index += 4) {
            byte[] operation = new byte[] {content[index], content[index + 1], content[index + 2], content[index + 3]};

            if (matchPattern(operation, ip_send_check_opcodes1[0])) {
                List<Object> result = sigCheck(ip_send_check_opcodes1, ip_send_check_rules1, content, index, operation, kallsyms, true);
                if (result != null) {
                    ip_send_check_results1.add(result);
                }
            }
            if (matchPattern(operation, ip_send_check_opcodes2[0])) {
                List<Object> result = sigCheck(ip_send_check_opcodes2, ip_send_check_rules2, content, index, operation, kallsyms, true);
                if (result != null) {
                    ip_send_check_results2.add(result);
                }
            }
            if (matchPattern(operation, ip_send_check_opcodes3[0])) {
                List<Object> result = sigCheck(ip_send_check_opcodes3, ip_send_check_rules3, content, index, operation, kallsyms, true);
                if (result != null) {
                    ip_send_check_results3.add(result);
                }
            }
            if (matchPattern(operation, ip_send_check_opcodes4[0])) {
                List<Object> result = sigCheck(ip_send_check_opcodes4, ip_send_check_rules4, content, index, operation, kallsyms, true);
                if (result != null) {
                    ip_send_check_results4.add(result);
                }
            }

            if (matchPattern(operation, ip_decrease_ttl_opcodes[0])) {
                List<Object> result = sigCheck(ip_decrease_ttl_opcodes, ip_decrease_ttl_rules, content, index, operation, kallsyms, false);
                if (result != null) {
                    ip_decrease_ttl_results.add(result);
                }
            }

            if (matchPattern(operation, ip6_forward_opcodes[0])) {
                List<Object> result = sigCheck(ip6_forward_opcodes, ip6_forward_rules, content, index, operation, kallsyms, false);
                if (result != null) {
                    ip6_forward_results.add(result);
                }
            }
        }

        if (ip_send_check_results1.size() > 0) {
            ip_send_check_results = ip_send_check_results1;
        } else if (ip_send_check_results2.size() > 0) {
            ip_send_check_results = ip_send_check_results2;
        } else if (ip_send_check_results3.size() > 0) {
            ip_send_check_results = ip_send_check_results3;
        } else {
            ip_send_check_results = ip_send_check_results4;
        }

        System.out.println("\nPatching decrement in ip_forward...");

        if (ip_send_check_results.size() == 1) {
            System.out.println("ip_send_check signature matched - 0x" + Integer.toHexString((int) ip_send_check_results.get(0).get(0)) + " - " + formatBytesList((List<byte[]>) ip_send_check_results.get(0).get(1)));
        } else {
            if (ip_send_check_results.size() > 1) {
                System.out.println("ERROR - too many matches for ip_send_check");
                for (List<Object> result : ip_send_check_results) {
                    System.out.println("ip_send_check signature matched - 0x" + Integer.toHexString((int) result.get(0)) + " - " + formatBytesList((List<byte[]>) result.get(1)));
                }
            } else {
                System.out.println("ERROR - no matches for ip_send_check");
            }
            System.exit(1);
        }
        if (ip_decrease_ttl_results.size() == 1) {
            System.out.println("ip_decrease_ttl signature matched - 0x" + Integer.toHexString((int) ip_decrease_ttl_results.get(0).get(0)) + " - " + formatBytesList((List<byte[]>) ip_decrease_ttl_results.get(0).get(1)));
        } else {
            if (ip_decrease_ttl_results.size() > 1) {
                System.out.println("ERROR - too many matches for ip_decrease_ttl");
            } else {
                System.out.println("ERROR - no matches for ip_decrease_ttl");
            }
            System.exit(1);
        }

        int ip_send_check_offset = (int) ip_send_check_results.get(0).get(0);
        int ip_decrease_ttl_offset = (int) ip_decrease_ttl_results.get(0).get(0);
        List<byte[]> ip_decrease_ttl_bytes = (List<byte[]>) ip_decrease_ttl_results.get(0).get(1);
        byte[] patch = new byte[ip_decrease_ttl_bytes.size() * 4];
        System.arraycopy(ip_decrease_ttl_bytes.get(0), 0, patch, 0, 4); // ldrh w?,[x??, #0x??]
        String Rn = null;
        String Rd = null;
        boolean found = false;
        for (int pos = 1; pos < 3; pos++) {
            if (matchPattern(ip_decrease_ttl_bytes.get(pos), new int[][]{add_sr_64})) {
                System.arraycopy(ip_decrease_ttl_bytes.get(pos), 0, patch, 4, 4); // add x??,x?,x?
                String bits = padbits(Integer.toBinaryString(ByteBuffer.wrap(ip_decrease_ttl_bytes.get(pos)).order(ByteOrder.LITTLE_ENDIAN).getInt()));
                Rn = bits.substring(bits.length() - 10, bits.length() - 5);
                Rd = bits.substring(bits.length() - 5);
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("ERROR - failed to build patch data");
            System.exit(1);
        }

        System.arraycopy(littleEndian(padbytes(new BigInteger("010100101000000000001000000" + Rn, 2).toByteArray())), 0, patch, 8, 4); // mov w?,#0x40
        System.arraycopy(littleEndian(padbytes(new BigInteger("10101010000" + Rd + "0000001111100000", 2).toByteArray())), 0, patch, 12, 4); // mov x0,x??
        System.arraycopy(littleEndian(padbytes(new BigInteger("0011100100000000001000" + Rd + Rn, 2).toByteArray())), 0, patch, 16, 4); // strb w?,[x??, #0x8]
        System.arraycopy(littleEndian(padbytes(new BigInteger("100101" + calcBranch(ip_decrease_ttl_offset + (4 * 5), ip_send_check_offset), 2).toByteArray())), 0, patch, 20, 4); // bl ip_send_check
        System.arraycopy(new byte[]{(byte) 0x1F, (byte) 0x20, (byte) 0x03, (byte) 0xD5}, 0, patch, 24, 4); // nop
        System.arraycopy(new byte[]{(byte) 0x1F, (byte) 0x20, (byte) 0x03, (byte) 0xD5}, 0, patch, 28, 4); // nop
        System.arraycopy(new byte[]{(byte) 0x1F, (byte) 0x20, (byte) 0x03, (byte) 0xD5}, 0, patch, 32, 4); // nop
        System.arraycopy(new byte[]{(byte) 0x1F, (byte) 0x20, (byte) 0x03, (byte) 0xD5}, 0, patch, 36, 4); // nop
        System.arraycopy(new byte[]{(byte) 0x1F, (byte) 0x20, (byte) 0x03, (byte) 0xD5}, 0, patch, 40, 4); // nop
        System.out.println("ip_forward patch:");
        System.out.println(byteslistToHex(ip_decrease_ttl_bytes));
        System.out.println(bytesToHex(patch));
        System.arraycopy(patch, 0, content, ip_decrease_ttl_offset, patch.length);

        System.out.println("\nPatching decrement in ip6_forward...");

        // Can occur in ip6mr_forward2 as well as ip6_forward. Just patch them both.
        if (ip6_forward_results.size() >= 1) {
            for (List<Object> result : ip6_forward_results) {
                System.out.println("ip6_forward_decrement signature matched - 0x" + Integer.toHexString((int) result.get(0)) + " - " + formatBytesList((List<byte[]>) result.get(1)));
            }
        } else {
            System.out.println("ERROR - no matches for ip6_forward");
            System.exit(1);
        }

        int count = 1;
        for (List<Object> result : ip6_forward_results) {
            int offset = (int) result.get(0);
            List<byte[]> bytelist = (List<byte[]>) result.get(1);
            byte[] patchdata = new byte[bytelist.size() * 4];
            int pos = 0;
            for (byte[] bytes : bytelist) {
                if (matchPattern(bytes, new int[][]{sub_i_32_1})) {
                    String bits = padbits(Integer.toBinaryString(ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).getInt()));
                    Rd = bits.substring(bits.length() - 5);
                    System.arraycopy(littleEndian(padbytes(new BigInteger("010100101000000000001000000" + Rd, 2).toByteArray())), 0, patchdata, pos, 4); // mov w?,#0x40
                } else {
                    System.arraycopy(bytes, 0, patchdata, pos, 4);
                }
                pos += 4;
            }
            System.out.println("ip6_forward patch " + count + ":");
            System.out.println(byteslistToHex(bytelist));
            System.out.println(bytesToHex(patchdata));
            System.arraycopy(patchdata, 0, content, offset, patchdata.length);
            count += 1;
        }

        try (FileOutputStream file = new FileOutputStream("kernel.patched")) {
            file.write(head);
            file.write(content);
            file.write(tail);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
        System.out.println("\nFile patched! Saved to 'kernel.patched'");
        System.exit(0);
    }

}

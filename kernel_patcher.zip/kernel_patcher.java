import java.lang.System;
import java.lang.StringBuilder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.math.BigInteger;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class kernel_patcher {

    // DDI0487_I_a_a-profile_architecture_reference_manual.pdf

    // C6.2.2 ADCS
    static int[] adcs_32 = {0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] adcs_64 = {1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.4 ADD (immediate)
    static int[] add_i_32 = {0, 0, 0, 1, 0, 0, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] add_i_64 = {1, 0, 0, 1, 0, 0, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.5 ADD (shifted register)
    static int[] add_sr_32 = {0, 0, 0, 0, 1, 0, 1, 1, -1, -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] add_sr_64 = {1, 0, 0, 0, 1, 0, 1, 1, -1, -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.12 AND (immediate)
    static int[] and_i_32 = {0, 0, 0, 1, 0, 0, 1, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] and_i_64 = {1, 0, 0, 1, 0, 0, 1, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.34 BL
    static int[] bl = {1, 0, 0, 1, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.54 CINC
    static int[] cinc_32 = {0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] cinc_64 = {1, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.61 CMN (shifted register)
    static int[] cmn_sr_32 = {0, 0, 1, 0, 1, 0, 1, 1, -1, -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 1, 1};
    static int[] cmn_sr_64 = {1, 0, 1, 0, 1, 0, 1, 1, -1, -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 1, 1};

    // C6.2.64 CMP (shifted register)
    static int[] cmp_sr_32 = {0, 1, 1, 0, 1, 0, 1, 1, -1, -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 1, 1};
    static int[] cmp_sr_64 = {1, 1, 1, 0, 1, 0, 1, 1, -1, -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 1, 1};

    // C6.2.164 LDP - Signed offset
    static int[] ldp_so = {-1, 0, 1, 0, 1, 0, 0, 1, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.170 LDRB (immediate) - Unsigned offset
    static int[] ldrb_i_uo = {0, 0, 1, 1, 1, 0, 0, 1, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.172 LDRH (immediate) - Unsigned offset
    static int[] ldrh_i_uo = {0, 1, 1, 1, 1, 0, 0, 1, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.220 MOV (to/from SP)
    static int[] mov_sp_32 = {0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] mov_sp_64 = {1, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.222 MOV (wide immediate)
    static int[] mov_wi_32 = {0, 1, 0, 1, 0, 0, 1, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] mov_wi_64 = {1, 1, 0, 1, 0, 0, 1, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.224 MOV (register)
    static int[] mov_r_32 = {0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1};
    static int[] mov_r_64 = {1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, -1, -1, -1, -1, -1};

    // C6.2.321 STP - Pre-index
    static int[] stp_bi_32 = {0, 0, 1, 0, 1, 0, 0, 1, 1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] stp_bi_64 = {1, 0, 1, 0, 1, 0, 0, 1, 1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.322 STR (immediate) - Unsigned offset
    static int[] str_i_uo_32 = {1, 0, 1, 1, 1, 0, 0, 1, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] str_i_uo_64 = {1, 1, 1, 1, 1, 0, 0, 1, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.324 STRB (immediate) - Unsigned offset
    static int[] strb_i_uo = {0, 0, 1, 1, 1, 0, 0, 1, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.326 STRH (immediate) - Unsigned offset
    static int[] strh_i_uo = {0, 1, 1, 1, 1, 0, 0, 1, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.357 SUB (immediate)
    static int[] sub_i_32 = {0, 1, 0, 1, 0, 0, 0, 1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
    static int[] sub_i_64 = {1, 1, 0, 1, 0, 0, 0, 1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // C6.2.245 PACIA, PACIA1716, PACIASP, PACIAZ, PACIZA
    static int[] paciasp = {1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1};

    // ----------------------------------------------------

    // and w?,w?,#0xf
    static int[] and_i_32__f = { 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // strh wzr,[x?, #0x?]
    static int[] strh_i_uo__wzr = { 0, 1, 1, 1, 1, 0, 0, 1, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 1, 1, 1, 1, 1 };

    // mov w?,#0xfffd
    static int[] mov_wi_32_fffd = {0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, -1, -1, -1, -1, -1};

    // mov w?,#0xfffe
    static int[] mov_wi_32_fffe = {0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, -1, -1, -1, -1, -1};

    // cinc w?,w?,hi
    static int[] cinc_32_hi = {0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 0, -1, -1, -1, -1, -1, 1, 0, 0, 1, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // sub w?,w?,#0x1
    static int[] sub_i_32_1 = {0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // add w?,w?,#0x1
    static int[] add_i_32_1 = {0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    // ----------------------------------------------------

    static int[] matchall = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};

    public static boolean matchPattern(byte[] bytes, int[][] pattern) {
        next: for (int[] bits : pattern) {
            for (int pos = 0; pos < 32; pos++) {
                if (bits[pos] != -1 && bits[pos] != ((bytes[(31 - pos) / 8] >> (31 - pos) % 8) & 0x1)) {
                    continue next;
                }
            }
            return true;
        }
        return false;
    }

    public static int findMatch(byte[] bytes, int[][][] patterns, List<Integer> matched_ops) {
        for (int index = 0; index < patterns.length; index++) {
            if (!matched_ops.contains(index) && matchPattern(bytes, patterns[index])) {
                return index;
            }
        }
        return -1;
    }

    public static List<Object> sigCheck(int[][][] patterns, int[][] rules, byte[] content, int index, byte[] operation) {
        List<Integer> matched_ops = new ArrayList<>();
        matched_ops.add(0);
        List<byte[]> matched_bytes = new ArrayList<>();
        matched_bytes.add(operation);
        int pos = index + 4;
        while (matched_ops.size() < patterns.length) {
            byte[] nextop = new byte[4];
            System.arraycopy(content, pos, nextop, 0, 4);
            int op_pos = findMatch(nextop, patterns, matched_ops);
            if (op_pos != -1) {
                boolean found = false;
                for (int[] rule : rules) {
                    if (rule[0] == op_pos && matched_ops.contains(rule[1])) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    matched_ops.add(op_pos);
                    matched_bytes.add(nextop);
                    pos += 4;
                    continue;
                }
            }
            break;
        }
        if (matched_ops.size() == patterns.length) {
            List<Object> result = new ArrayList<>();
            result.add(index);
            result.add(matched_bytes);
            return result;
        }
        return null;
    }

    public static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    public static String byteslistToHex(List<byte[]> bytes) {
        StringBuilder hexBuilder = new StringBuilder();
        for (byte[] byteArray : bytes) {
            for (byte b : byteArray) {
                hexBuilder.append(String.format("%02x", b));
            }
        }
        return hexBuilder.toString().trim();
    }

    public static String formatBytesList(List<byte[]> bytes){
        boolean passed = false;
        StringBuilder hexBuilder = new StringBuilder();
        hexBuilder.append("[");
        for (byte[] byteArray : bytes) {
            if (passed) {
                hexBuilder.append(", ");
            } else {
                passed = true;
            }
            hexBuilder.append("'");
            for (byte b : byteArray) {
                hexBuilder.append(String.format("%02x", b));
            }
            hexBuilder.append("'");
        }
        hexBuilder.append("]");
        return hexBuilder.toString().trim();
    }

    public static byte[] findInstr(List<byte[]> byteslist, int[] instruction, int min, int max) {
        for (int pos = min; pos <= max; pos++) {
            if (matchPattern(byteslist.get(pos), new int[][]{instruction})) {
                return byteslist.get(pos);
            }
        }
        System.out.println("ERROR - can't locate instruction");
        System.exit(1);
        return null; // fuck you java
    }

    public static byte[] littleEndian(byte[] value) {
        final int length = value.length;
        byte[] result = new byte[length];
        for(int i = 0; i < length; i++) {
            result[length - i - 1] = value[i];
        }
        return result;
    }

    public static String padbits(String bits){
        return "00000000000000000000000000000000".substring(bits.length()) + bits;
    }

    public static byte[] padbytes(byte[] bytes){
        byte[] result = new byte[4];
        if (bytes.length > 4)
            System.arraycopy(bytes, bytes.length - 4, result, 0, 4);
        else
            System.arraycopy(bytes, 0, result, 4 - bytes.length, bytes.length);
        return result;
    }

    public static boolean startsWith(byte[] source, byte[] target) {
        if (source.length < target.length)
            return false;

        for (int i = 0; i < target.length; i++) {
            if (source[i] != target[i])
                return false;
        }
        return true;
    }

    public static void main(String[] args) {
        System.out.println("Opening file 'kernel' for patching...");
        byte[] content = new byte[0];
        try {
            FileInputStream file = new FileInputStream("kernel");
            content = new byte[(int) file.getChannel().size()];
            if (file.read(content) <= 0) {
                System.out.println("ERROR - file 'kernel' is empty or can not be read");
                System.exit(1);
            }
            file.close();
        } catch (IOException e) {
            System.out.println("ERROR - file 'kernel' does not exist");
            System.exit(1);
        }

        // TODO: map relation with registers between instructions for more accurate matches
        // TODO: better account for fixed arguments, static defs are lame

        byte[] head = new byte[0];
        byte[] tail = new byte[0];
        if (startsWith(content, "UNCOMPRESSED_IMG".getBytes())) {
            head = Arrays.copyOfRange(content, 0, 20);
            int dtb_offset_le = ByteBuffer.wrap(content, 16, 4).order(ByteOrder.LITTLE_ENDIAN).getInt();
            tail = Arrays.copyOfRange(content, 20 + dtb_offset_le, content.length);
            content = Arrays.copyOfRange(content, 20, 20 + dtb_offset_le);
        }

        // NOTE: Patterns are assumed to be sequential for optimization and rules must be too. (eg. {2, 1} is invalid)
        // NOTE: For this same reason, matchall must be at the end of a pattern.
        // NOTE: The first definition in a pattern is always static so rules should never reference it. (eg. {0, 1} is invalid)

        /*fc010f485ec 69 6a 41 79     ldrh       w9,[x19, #0xb4]
        fc010f485f0 aa ff 9f 52     mov        w10,#0xfffd
        fc010f485f4 16 01 09 8b     add        x22,x8,x9
        fc010f485f8 c8 16 40 79     ldrh       w8,[x22, #0xa]
        fc010f485fc c9 22 40 39     ldrb       w9,[x22, #0x8]
        fc010f48600 1f 01 0a 6b     cmp        w8,w10
        fc010f48604 08 95 88 1a     cinc       w8,w8,hi
        fc010f48608 29 05 00 51     sub        w9,w9,#0x1
        fc010f4860c 08 05 00 11     add        w8,w8,#0x1
        fc010f48610 c8 16 00 79     strh       w8,[x22, #0xa]
        fc010f48614 c9 22 00 39     strb       w9,[x22, #0x8]*/

        int[][][] ip_decrease_ttl_opcodes = { {ldrh_i_uo}, {mov_wi_32_fffd, mov_wi_32_fffe}, {add_sr_64}, {ldrh_i_uo}, {ldrb_i_uo}, {cmp_sr_32}, {cinc_32_hi}, {sub_i_32_1}, {add_i_32_1}, {strh_i_uo}, {strb_i_uo} };
        int[][] ip_decrease_ttl_rules = { {1, 5}, {2, 3}, {2, 4}, {2, 9}, {2, 10}, {3, 5}, {3, 6}, {3, 8}, {3, 9}, {4, 7}, {4, 10}, {5, 6}, {6, 9}, {7, 10}, {8, 9} };

        /*f8008f42430 69 c2 41 79     ldrh       w9,[x19, #0xe0]
        f8008f42434 08 01 09 8b     add        x8,x8,x9
        f8008f42438 09 1d 40 39     ldrb       w9,[x8, #0x7]
        f8008f4243c 29 05 00 51     sub        w9,w9,#0x1
        f8008f42440 09 1d 00 39     strb       w9,[x8, #0x7]*/
        int[][][] ip6_forward_opcodes = { {ldrh_i_uo}, {add_sr_64}, {ldrb_i_uo}, {sub_i_32_1}, {strb_i_uo} };
        int[][] ip6_forward_rules = { {1, 2}, {2, 3}, {3, 4} };

        List<List<Object>> ip_decrease_ttl_results = new ArrayList<>();
        List<List<Object>> ip6_forward_results = new ArrayList<>();
        for (int index = 0; index < content.length - 3; index += 4) {
            byte[] operation = new byte[] {content[index], content[index + 1], content[index + 2], content[index + 3]};

            if (matchPattern(operation, ip_decrease_ttl_opcodes[0])) {
                List<Object> result = sigCheck(ip_decrease_ttl_opcodes, ip_decrease_ttl_rules, content, index, operation);
                if (result != null) {
                    ip_decrease_ttl_results.add(result);
                }
            }

            if (matchPattern(operation, ip6_forward_opcodes[0])) {
                List<Object> result = sigCheck(ip6_forward_opcodes, ip6_forward_rules, content, index, operation);
                if (result != null) {
                    ip6_forward_results.add(result);
                }
            }
        }

        System.out.println("\nPatching decrement in ip_forward...");

        if (ip_decrease_ttl_results.size() == 1) {
            System.out.println("ip_decrease_ttl signature matched - 0x" + Integer.toHexString((int) ip_decrease_ttl_results.get(0).get(0)) + " - " + formatBytesList((List<byte[]>) ip_decrease_ttl_results.get(0).get(1)));
        } else {
            if (ip_decrease_ttl_results.size() > 1) {
                System.out.println("ERROR - too many matches for ip_decrease_ttl");
            } else {
                System.out.println("ERROR - no matches for ip_decrease_ttl");
            }
            System.exit(1);
        }

        int ip_decrease_ttl_offset = (int) ip_decrease_ttl_results.get(0).get(0);
        List<byte[]> ip_decrease_ttl_bytes = (List<byte[]>) ip_decrease_ttl_results.get(0).get(1);
        byte[] patchdata = new byte[ip_decrease_ttl_bytes.size() * 4];

        System.arraycopy(ip_decrease_ttl_bytes.get(0), 0, patchdata, 0, 4); // ldrh w?,[x?, #0x?]
        System.arraycopy(findInstr(ip_decrease_ttl_bytes, add_sr_64, 1, 2), 0, patchdata, 4, 4); // add x?,x?,x?

        // load checksum
        byte[] instruction = findInstr(ip_decrease_ttl_bytes, ldrh_i_uo, 3, 5);
        String bits = padbits(Integer.toBinaryString(ByteBuffer.wrap(instruction).order(ByteOrder.LITTLE_ENDIAN).getInt()));
        String imm_c = bits.substring(10, 22);
        String Rn = bits.substring(22, 27);
        String Rt_c = bits.substring(27, 32);
        System.arraycopy(instruction, 0, patchdata, 8, 4); // ldrh w?,[x?, #0x?]

        // load ttl
        instruction = findInstr(ip_decrease_ttl_bytes, ldrb_i_uo, 3, 5);
        bits = padbits(Integer.toBinaryString(ByteBuffer.wrap(instruction).order(ByteOrder.LITTLE_ENDIAN).getInt()));
        String imm_t = bits.substring(10, 22);
        String Rt_t = bits.substring(27, 32);
        System.arraycopy(instruction, 0, patchdata, 12, 4); // ldrb w?,[x?, #0x?]

        System.arraycopy(littleEndian(padbytes(new BigInteger("00001011000" + Rt_t + "000000" + Rt_c + Rt_c, 2).toByteArray())), 0, patchdata, 16, 4); // add w?,w?,w?
        System.arraycopy(littleEndian(padbytes(new BigInteger("010100101000000000001000000" + Rt_t, 2).toByteArray())), 0, patchdata, 20, 4); // mov w?,#0x40
        System.arraycopy(littleEndian(padbytes(new BigInteger("01001011000" + Rt_t + "000000" + Rt_c + Rt_c, 2).toByteArray())), 0, patchdata, 24, 4); // sub w?,w?,w?
        System.arraycopy(littleEndian(padbytes(new BigInteger("00101011010" + Rt_c + "010000" + Rt_c + Rt_c, 2).toByteArray())), 0, patchdata, 28, 4); // adds w?,w?,w?, LSR #0x10
        System.arraycopy(littleEndian(padbytes(new BigInteger("0011100100" + imm_t + Rn + Rt_t, 2).toByteArray())), 0, patchdata, 32, 4); // strb w?,[x?, #0x?]
        System.arraycopy(littleEndian(padbytes(new BigInteger("0111100100" + imm_c + Rn + Rt_c, 2).toByteArray())), 0, patchdata, 36, 4); // strh w?,[x?, #0x?]
        System.arraycopy(new byte[]{(byte) 0x1F, (byte) 0x20, (byte) 0x03, (byte) 0xD5}, 0, patchdata, 40, 4); // nop
        System.out.println("ip_forward patch:");
        System.out.println(byteslistToHex(ip_decrease_ttl_bytes));
        System.out.println(bytesToHex(patchdata));
        System.arraycopy(patchdata, 0, content, ip_decrease_ttl_offset, patchdata.length);

        System.out.println("\nPatching decrement in ip6_forward...");

        // Can occur in ip6mr_forward2 as well as ip6_forward. Just patch them both.
        if (ip6_forward_results.size() >= 1) {
            for (List<Object> result : ip6_forward_results) {
                System.out.println("ip6_forward_decrement signature matched - 0x" + Integer.toHexString((int) result.get(0)) + " - " + formatBytesList((List<byte[]>) result.get(1)));
            }
        } else {
            System.out.println("ERROR - no matches for ip6_forward");
            System.exit(1);
        }

        int count = 1;
        for (List<Object> result : ip6_forward_results) {
            int offset = (int) result.get(0);
            List<byte[]> bytelist = (List<byte[]>) result.get(1);
            patchdata = new byte[bytelist.size() * 4];
            int pos = 0;
            for (byte[] bytes : bytelist) {
                if (matchPattern(bytes, new int[][]{sub_i_32_1})) {
                    bits = padbits(Integer.toBinaryString(ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).getInt()));
                    String Rd = bits.substring(bits.length() - 5);
                    System.arraycopy(littleEndian(padbytes(new BigInteger("010100101000000000001000000" + Rd, 2).toByteArray())), 0, patchdata, pos, 4); // mov w?,#0x40
                } else {
                    System.arraycopy(bytes, 0, patchdata, pos, 4);
                }
                pos += 4;
            }
            System.out.println("ip6_forward patch " + count + ":");
            System.out.println(byteslistToHex(bytelist));
            System.out.println(bytesToHex(patchdata));
            System.arraycopy(patchdata, 0, content, offset, patchdata.length);
            count += 1;
        }

        try (FileOutputStream file = new FileOutputStream("kernel.patched")) {
            file.write(head);
            file.write(content);
            file.write(tail);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
        System.out.println("\nFile patched! Saved to 'kernel.patched'");
        System.exit(0);
    }
}
